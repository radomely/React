import React, { Component } from 'react';
import {connect} from 'react-redux';
import {asyncData} from './redux/actions/getNewsActions';
import './App.css';
import All from './All/All';

class App extends Component {

  componentDidMount() {
    this.props.fetch();
  }
  render() {
    return (
      <div className="App">
      <header></header>
      <All/>
      </div>
    );
  }
}


const MDTP = dispatch => ({
  fetch: () => dispatch(asyncData())
})

export default connect(null,MDTP)(App);
