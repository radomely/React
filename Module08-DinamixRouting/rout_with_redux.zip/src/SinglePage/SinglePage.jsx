import React from 'react';
import './SinglePage.css';
const SinglePage = ({data}) => {
    console.log(data);
    return (
        <div className='article'>
            <img src={data.urlToImage} alt={data.title} className='article-img'/>
            <h2 className='article-title'>{data.title}</h2>
            <p className='article-text'>{data.description}</p>
            <a href={data.url} target='_blank' className='article-link'>Читати на сайті</a>
        </div>
    );
};

export default SinglePage;